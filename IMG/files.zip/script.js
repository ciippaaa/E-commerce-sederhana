function openLogin() {
  document.getElementById("loginPage").style.display = "flex";
}

function closeLogin() {
  document.getElementById("loginPage").style.display = "none";
}

function openRegister() {
  document.getElementById("registerPage").style.display = "flex";
}

function closeRegister() {
  document.getElementById("registerPage").style.display = "none";
}

window.onclick = function(e) {
  const loginModal = document.getElementById("loginPage");
  const registerModal = document.getElementById("registerPage");

  if (e.target === loginModal) {
    loginModal.style.display = "none";
  }
  if (e.target === registerModal) {
    registerModal.style.display = "none";
  }
}
